from flask import *
import pandas as pd
from flask import jsonify
import os
from flask_cors import CORS, cross_origin
import re
from datetime import datetime
import paramiko
from scp import SCPClient
import ast

regex = r"\[(.+?)\].+?Active Learning Request:\s+\{(.+?)\}"
regex_filename = r".+?Selected Image:(.+?);.+?"

app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

def parse_datastore_json(file_json_data):
  count_radiologists = {}
  total_time_radiologists = {}
  id_list = []
  ann_list = []
  ts_list = []
  for key, val in file_json_data.items():
    if key == 'objects':
      for key,val in file_json_data["objects"].items():
        try:
            name  = val["image"]["info"]["strategy"]["random"]["client_id"]
            name = name.upper()
        except:
            name = None
        try:
            img_id = val["image"]["info"]["name"]
        except:
            img_id = None
        try:
            ts_start= int(val["image"]["info"]["strategy"]["random"]["ts"])
        except:
            ts_start = None
        try:
            ts_end = int(val["labels"]["final"]["info"]["ts"])
        except:
            ts_end = None
        if name and name in count_radiologists.keys():
            count_radiologists[name] += 1
            if ts_start and ts_end and name in total_time_radiologists.keys():
                total_time_radiologists[name] += (ts_end-ts_start)/(60*60)
            elif ts_start and ts_end and name not in total_time_radiologists.keys():
               total_time_radiologists[name] = (ts_end-ts_start)/(60*60)
        elif name and name not in count_radiologists.keys() and name not in total_time_radiologists.keys():
            count_radiologists[name] = 1
            if ts_start and ts_end:
                total_time_radiologists[name] = (ts_end-ts_start)/(60*60)
        else:
            if 'MISSING' in count_radiologists.keys():
                count_radiologists['MISSING'] += 1
                if ts_start and ts_end:
                    total_time_radiologists['MISSING'] += (ts_end-ts_start)/(60*60)
            else:
                count_radiologists['MISSING'] = 1
                if ts_start and ts_end:
                    total_time_radiologists['MISSING'] = (ts_end-ts_start)/(60*60)
    if not total_time_radiologists:
       total_time_radiologists['MISSING'] = 0
  return count_radiologists, total_time_radiologists

def parse_log(datalines,usecase):
  log_parse_arr = []
  for index,line in enumerate(datalines):
    matches = re.finditer(regex, line, re.MULTILINE)
    if (index+1)<len(datalines):
      matches_filename = re.finditer(regex_filename,datalines[index+1],re.MULTILINE)
    else:
      matches_filename = None
    for matchNum, match in enumerate(matches, start=1):
      dict_data = {}
      dict_data['timestamp'] = datetime.strptime(match.group(1),'%Y-%m-%d %H:%M:%S,%f')
      dict_clientdetails = ast.literal_eval("{"+ match.group(2).strip()+"}")
      if 'client_id' in dict_clientdetails.keys():
        dict_data['name'] = dict_clientdetails['client_id'].upper()
      else:
         dict_data['name'] = 'MISSING'
      dict_data['project'] = usecase
      if matches_filename:
        for matchNumFileName, match_filename in enumerate(matches_filename,start=1):
          dict_data['filename'] = match_filename.group(1).strip()
      log_parse_arr.append(dict_data)         
  log_parse_df = pd.DataFrame(log_parse_arr)
  return log_parse_df

def login_parse():
  data_lines = []
  # Getting the current date
  current_date = datetime.now()
  datastore_v2_lungct = 'datastore_v2_lungct_' + current_date.strftime('%Y-%m-%d') + '.json'
  log_lungct = 'nohup_lungct_' + current_date.strftime('%Y-%m-%d') + '.out'
  # Transfering the datastore database JSON and logs
  try:
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.217.29.157',username='anand',password='anand@1234')
    scp = SCPClient(ssh.get_transport())
    scp.get('/home/anand/datasets/datastore_v2.json','/home/anand/'+ datastore_v2_lungct)
    print('SCP of Data Store Lung completed...')
    scp.get('/home/anand/nohup.out','/home/anand/' + log_lungct)
    scp.close()
    ssh.close()
  except Exception as e:
    print(e)
  datastore_v2_cardiacct = 'datastore_v2_cardiacct_' + current_date.strftime('%Y-%m-%d') + '.json'
  log_cardiacct = 'nohup_cardiacct_' + current_date.strftime('%Y-%m-%d') + '.out'
  try:
    ssh = paramiko.SSHClient()
    ssh.load_system_host_keys()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect('10.217.29.158',username='anand',password='anand@1234')
    scp = SCPClient(ssh.get_transport())
    scp.get('/home/anand/datasets/datastore_v2.json','/home/anand/'+ datastore_v2_cardiacct)
    print('SCP of Data Store Cardiac completed...')
    scp.get('/home/anand/nohup.out','/home/anand/' + log_cardiacct)
    scp.close()
    ssh.close()
  except Exception as e:
    print(e)
  # Get the current log parsring output
  f = open(log_lungct,'r')
  data_lines_lung = f.readlines()
  f = open(log_cardiacct,'r')
  data_lines_cardiac = f.readlines()
  log_parse_df_lung = parse_log(data_lines_lung,'LUNG')
  log_parse_df_cardiac = parse_log(data_lines_cardiac,'CARDIAC')

  log_parse_df = pd.concat([log_parse_df_lung,log_parse_df_cardiac])
  # Get the JSON parser output
  file_object = open(datastore_v2_lungct,'rb')
  file_json_data = json.load(file_object)
  count_radiologists_lung, total_time_radiologists_lung = parse_datastore_json(file_json_data)
  file_object = open(datastore_v2_cardiacct,'rb')
  file_json_data = json.load(file_object)
  count_radiologists_cardiac, total_time_radiologists_cardiac = parse_datastore_json(file_json_data)
  
  count_radiologists_lung_df = pd.DataFrame.from_dict(count_radiologists_lung, orient='index').reset_index()
  count_radiologists_lung_df.columns = ['name','count_studies_annotated']
  count_radiologists_lung_df['project'] = 'LUNG'
  total_time_radiologists_lung_df = pd.DataFrame.from_dict(total_time_radiologists_lung, orient='index').reset_index()
  total_time_radiologists_lung_df.columns = ['name','total_annotated_time_hrs']
  total_time_radiologists_lung_df['project'] = 'LUNG'
  count_radiologists_cardiac_df = pd.DataFrame.from_dict(count_radiologists_cardiac,orient='index').reset_index()
  count_radiologists_cardiac_df.columns = ['name','count_studies_annotated']
  count_radiologists_cardiac_df['project'] = 'CARDIAC'
  total_time_radiologists_cardiac_df = pd.DataFrame.from_dict(total_time_radiologists_cardiac,orient='index').reset_index()
  total_time_radiologists_cardiac_df.columns = ['name','total_annotated_time_hrs']
  total_time_radiologists_cardiac_df['project'] = 'CARDIAC'
  
  count_radiologists_df = pd.concat([count_radiologists_lung_df,count_radiologists_cardiac_df])
  total_time_radiologists_df = pd.concat([total_time_radiologists_lung_df,total_time_radiologists_cardiac_df])

  return log_parse_df, count_radiologists_df, total_time_radiologists_df

@app.route('/login_annotate')             
@cross_origin()                                                                     
def login_annotate():
  log_parse_df, count_radiologists_df, total_time_radiologists_df = login_parse()
  log_parse_df['filename'] = [str(x) for x in log_parse_df['filename']]
  meas = log_parse_df.to_dict(orient='records')
  dataSrc = {}
  dataSrc['dataSrc'] = meas
  return jsonify(dataSrc)
  
@app.route('/login_summary')             
@cross_origin()                                                                     
def login_summary():
  log_parse_df, count_radiologist_df, total_time_radiologists_df = login_parse()
  summary_df = log_parse_df[['name','project','filename']].groupby(['name','project']).count().reset_index()
  print(summary_df)
  summary_df.columns = ['name','project','count_reviewed']
  summary_df = summary_df.merge(count_radiologist_df,how='left',on=['name','project']).reset_index()
  summary_df.fillna('NOT AVAILABLE', inplace=True)
  print(summary_df)
  summary_df = summary_df.merge(total_time_radiologists_df,how='left',on=['name','project']).reset_index()
  summary_df.fillna('NOT AVAILABLE', inplace=True)
  summary_df = summary_df[summary_df['name']!='MISSING']
  print(summary_df)
  meas = summary_df.to_dict(orient='records')
  dataSrc = {}
  dataSrc['dataSrc'] = meas
  return jsonify(dataSrc)

if __name__ == "__main__":
    app.run(host="10.217.29.156", port=8003,debug=True)