import pandas as pd
import os

dir_path = '/home/anand/airflow/deid_info/'
list_files = os.listdir(dir_path)
data = []
def get_file(x):
  print(x)
  data = []
  print('here1')
  # iterate over each line as a ordered dictionary and print only few column by column name
  with open(dir_path+x, 'r') as read_obj:
    file_lines = read_obj.readlines()
    data = []
    for line in file_lines:
      line_split = line.split("||")
      if len(line_split)>6 and len(line_split)<=7:
        line_split[2] = line_split[2] + line_split[3]
        line_split[3] = line_split[4]
        line_split[4] = line_split[5]
        data.append(line_split[:-1])
      elif len(line_split)==6:
        data.append(line_split)
      else:
        print(x)
        data.append(['','','','','',''])
    data = pd.DataFrame(data,columns=['study_identifier','original_patient_id','dicom_original','anon_patient_id','dicom_anonymize','modality'])
    data = data[data['study_identifier']!='study_identifier']
    #data = data[['study_identifier','original_patient_id','anon_patient_id']]
    data.drop_duplicates(inplace=True)
    print(data)
  return data
        
data = [get_file(x) for x in list_files]
data = pd.concat(data)
data.fillna('',inplace=True)
data.drop_duplicates(inplace=True)
data.to_csv('/home/anand/airflow/deid_info.csv',sep='|',index=False)