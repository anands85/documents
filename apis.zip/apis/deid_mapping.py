from flask import *
import pandas as pd
from flask import jsonify
import os
from flask_cors import CORS, cross_origin
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

data = pd.read_csv('/home/anand/airflow/deid_info.csv',sep='|')

@app.route('/deid_mapping')             
@cross_origin()                                                                     
def deid_mapping():
  meas = data.to_dict(orient='records')
  dataSrc = {}
  dataSrc['dataSrc'] = meas
  return jsonify(dataSrc)

if __name__ == "__main__":
    app.run(host="10.217.29.156", port=8001,debug=True)