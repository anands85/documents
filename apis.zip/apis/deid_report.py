from flask import *
import pandas as pd
from flask import jsonify
import os
from flask_cors import CORS, cross_origin
app = Flask(__name__)
cors = CORS(app)
app.config['CORS_HEADERS'] = 'Content-Type'

dir_path = '/home/anand/airflow/anon_report/'
list_files = os.listdir(dir_path)
data = []
for file_name in list_files:
  try:
    data.append(pd.read_csv(dir_path+file_name,sep="|",names=['study_identifier','patient_id','report_text','patient_gender','study_date','patient_birth_date','patient_age','modality']))
  except:
    print(file_name)    
data = pd.concat(data)
#data['modality'] = 'CT'
data = data[data['study_identifier']!='study_identifier']
#data2 = pd.read_csv('reports_de_id_data.csv')
#data2.drop(columns='id',inplace=True)
#data2['modality'] = 'CR'
#data = pd.concat([data,data2])
data.fillna('',inplace=True)
data.drop_duplicates(inplace=True)

@app.route('/deid_report')             
@cross_origin()                                                                     
def deid_report():
  meas = data.to_dict(orient='records')
  dataSrc = {}
  dataSrc['dataSrc'] = meas
  return jsonify(dataSrc)

if __name__ == "__main__":
    app.run(host="10.217.29.156", port=8002,debug=True)